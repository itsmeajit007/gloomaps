function createTreeElement(data) {
    // Create <li> for the current node
    const li = document.createElement('li');
    li.className = 'tree-list';

    const div = document.createElement('div');
    div.className = 'txt-wrapper';
    div.setAttribute('draggable', 'true');

    const textarea = document.createElement('textarea');
    textarea.className = 'dis';
    textarea.maxLength = 250;
    textarea.textContent = data.label; // Set the label from JSON

    // Append elements to the div
    div.appendChild(textarea);
    // Append the div to the li
    li.appendChild(div);

    // If there are children, create a nested <ul> and append child elements
    if (data.children && data.children.length > 0) {
        const childUl = document.createElement('ul'); // Create a <ul> for children
        data.children.forEach(child => {
            const childElement = createTreeElement(child); // Recursive call
            childUl.appendChild(childElement); // Append child <li> to child <ul>
        });
        li.appendChild(childUl); // Append child <ul> to current <li>
    }

    return li; // Return the constructed <li>
}

async function getTreeJson() {
    try {
        const response = await fetch('../treeData.json'); // Fetch the JSON file
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const parsedJson = await response.json(); // Parse the JSON
        console.log(JSON.stringify(parsedJson, null, 2)); // Log the parsed JSON

        const treeElement = createTreeElement(parsedJson); // Create the tree

        const viewTree = document.getElementById('viewTree');
        viewTree.innerHTML = ''; // Clear any existing content
        // Append the created treeElement to viewTree
        viewTree.appendChild(treeElement);
    } catch (error) {
        console.error('Error fetching the JSON file:', error);
    }
}

document.addEventListener("DOMContentLoaded", function () {
    const canvasContainer = document.getElementById('canvas_container');
    const svgTarget = document.getElementById('target');

    // Function to get and log the screen dimensions
    async function checkScreenDimensions() {
        var screenWidth = window.innerWidth;
        var screenHeight = window.innerHeight;

        canvasContainer.style.height = screenHeight + 'px';
        canvasContainer.style.width = screenWidth + 'px';

        await getTreeJson(); // Call the async function here
    }

    // Center the canvas horizontally in the viewport
    function centerCanvas() {
        const canvas = document.getElementById('canvas');
        const centerX = (canvas.offsetWidth - canvasContainer.clientWidth) / 2;

        // Scroll to center the canvas
        canvasContainer.scrollTo(centerX, 0);
    }

    // Check initial screen dimensions and center canvas
    checkScreenDimensions();
    centerCanvas();

    // Add event listener for window resize
    window.addEventListener("resize", function () {
        checkScreenDimensions();
        centerCanvas();
    });

    svgTarget.addEventListener('click', function () {
        centerCanvas();
    });

    // Click-and-hold dragging functionality
    let isDragging = false;
    let lastMouseX, lastMouseY;

    const handleMouseDown = (e) => {
        isDragging = true;
        lastMouseX = e.clientX;
        lastMouseY = e.clientY;

        // Prevent text selection
        e.preventDefault();
    };

    const handleMouseMove = (e) => {
        if (!isDragging) return;

        const deltaX = lastMouseX - e.clientX;
        const deltaY = lastMouseY - e.clientY;

        canvasContainer.scrollBy(deltaX, deltaY);

        lastMouseX = e.clientX;
        lastMouseY = e.clientY;
    };

    const handleMouseUp = () => {
        isDragging = false;
    };

    // Event listeners for dragging
    canvasContainer.addEventListener('mousedown', handleMouseDown);
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
});
