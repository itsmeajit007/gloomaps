
// document.addEventListener('DOMContentLoaded', function () {
//     // Select the div element using querySelector (assuming there is only one element with class "tree")
//     var div = document.querySelector('.tree');

//     // Get the height of the div (content only, excluding padding, border, and margin)
//     var divHeight = div.clientHeight;

//     console.log('Height (content only):', divHeight);
// });