function canvasWrapper() {
    const wrapper = document.querySelector('.txt-wrapper');

    const createAddBottomLevelButton = (target) => {
        const html = `<div class="add-bottom-level"><i class="fal fa-plus"></i> <span>Add bottom level</span></div>`;
        target.insertAdjacentHTML('beforeend', html);
    };

    const removeAddBottomLevelButton = (target) => {
        const addSubLevel = target.querySelector('.add-bottom-level');
        if (addSubLevel) addSubLevel.remove();
    };

    const createAddRightLevelButton = (target) => {
        const html = `<div class="add-right-level"><i class="fal fa-plus"></i> <span>Add right level</span></div>`;
        target.insertAdjacentHTML('beforeend', html);
    };

    const removeAddRightLevelButton = (target) => {
        const addRightLevel = target.querySelector('.add-right-level');
        if (addRightLevel) addRightLevel.remove();
    };

    const createAddLeftLevelButton = (target) => {
        const html = `<div class="add-left-level"><i class="fal fa-plus"></i> <span>Add left level</span></div>`;
        target.insertAdjacentHTML('beforeend', html);
    };

    const removeAddLeftLevelButton = (target) => {
        const addLeftLevel = target.querySelector('.add-left-level');
        if (addLeftLevel) addLeftLevel.remove();
    };

    const updateBox2Visibility = (wrapper) => {
        const parentLi = wrapper.closest('.tree-list');
        const childUl = parentLi.querySelector('ul');
        const box2 = wrapper.querySelector('.box2');

        if (box2) {
            if (childUl && childUl.children.length > 0) {
                box2.classList.remove('hidden');
                box2.style.display = 'block';
            } else {
                box2.classList.add('hidden');
                box2.style.display = 'none';
            }
        }
    };

    const attachTxtWrapperEvents = (txtWrapper) => {
        // Add drag-and-drop event listeners
        txtWrapper.setAttribute('draggable', true);

        txtWrapper.addEventListener('dragstart', (event) => {
            event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('text/html', txtWrapper.outerHTML);
            txtWrapper.classList.add('dragging');
        });

        txtWrapper.addEventListener('dragend', () => {
            txtWrapper.classList.remove('dragging');
        });

        const treeListItems = document.querySelectorAll('.tree-list');
        treeListItems.forEach(item => {
            item.addEventListener('dragover', (event) => {
                event.preventDefault(); // Allow drop
                event.dataTransfer.dropEffect = 'move';
            });

            item.addEventListener('drop', (event) => {
                event.preventDefault();
                const draggedElement = document.querySelector('.txt-wrapper.dragging');

                if (draggedElement && draggedElement !== item) {
                    // Remove the original item
                    const parentLi = draggedElement.closest('.tree-list');
                    parentLi.remove();

                    // Insert the dragged item before the current item
                    item.insertAdjacentHTML('beforebegin', draggedElement.outerHTML);

                    // Re-attach events to the newly inserted element
                    const newTxtWrapper = item.previousElementSibling.querySelector('.txt-wrapper');
                    attachTxtWrapperEvents(newTxtWrapper);
                }
            });
        });

        txtWrapper.addEventListener('mouseenter', () => {
            createAddBottomLevelButton(txtWrapper);
            createAddRightLevelButton(txtWrapper);
            createAddLeftLevelButton(txtWrapper);
        });

        txtWrapper.addEventListener('mouseleave', () => {
            removeAddBottomLevelButton(txtWrapper);
            removeAddRightLevelButton(txtWrapper);
            removeAddLeftLevelButton(txtWrapper);
        });

        txtWrapper.addEventListener('click', function (event) {
            const addSubLevelButton = event.target.closest('.add-bottom-level');
            if (addSubLevelButton) {
                addSubLevelClickHandler(txtWrapper);
                return;
            }

            const addRightLevelButton = event.target.closest('.add-right-level');
            if (addRightLevelButton) {
                addRightLevelClickHandler(txtWrapper);
                return;
            }

            const addLeftLevelButton = event.target.closest('.add-left-level');
            if (addLeftLevelButton) {
                addLeftLevelClickHandler(txtWrapper);
                return;
            }

            const activeWrapper = document.querySelector('.txt-wrapper.active');
            if (activeWrapper && activeWrapper !== txtWrapper) {
                activeWrapper.classList.remove('active');
                const textarea = activeWrapper.querySelector('textarea');
                if (textarea) {
                    textarea.classList.add('dis');
                }
                const activeBox1 = activeWrapper.querySelector('.box1');
                const activeBox2 = activeWrapper.querySelector('.box2');
                if (activeBox1) activeBox1.style.display = 'none';
                if (activeBox2) activeBox2.style.display = 'none';
            }

            const box1 = txtWrapper.querySelector('.box1');
            const box2 = txtWrapper.querySelector('.box2');
            const isActive = txtWrapper.classList.toggle('active');
            if (isActive) {
                if (box1) box1.style.display = 'block';
                if (box2) box2.style.display = 'block';
            } else {
                if (box1) box1.style.display = 'none';
                if (box2) box2.style.display = 'none';
            }
        });

        txtWrapper.addEventListener('dblclick', function () {
            const textarea = txtWrapper.querySelector('textarea');
            if (textarea) {
                textarea.classList.remove('dis');
                textarea.focus();
            }
        });

        txtWrapper.addEventListener('input', function (event) {
            const textarea = event.target.closest('textarea');
            if (textarea) {
                textarea.innerHTML = textarea.value;
                textarea.style.height = '20px'; // Reset height
                textarea.style.height = `${textarea.scrollHeight}px`; // Set new height
                updateJson();
            }
        });


        // Update box2 visibility when children are modified
        const checkChildItems = () => {
            updateBox2Visibility(txtWrapper);
        };

        checkChildItems();

        // Handle click on box1 to delete item
        const box1 = txtWrapper.querySelector('.box1');
        if (box1) {
            box1.addEventListener('click', (event) => {
                event.stopPropagation(); // Prevent triggering other click events
                const parentLi = txtWrapper.closest('.tree-list'); // Get the parent list item
                const parentUl = parentLi.parentNode; // Get the parent <ul> of the item
                parentLi.remove(); // Remove the parent item

                // Check if the parent <ul> is empty
                if (parentUl.children.length === 0) {
                    parentUl.remove(); // Remove the <ul> if it's empty
                }

                // Recheck child items for the previous parent to update box2 display
                // updateBox2Visibility(parentLi.closest('.txt-wrapper'));
                checkChildItems();

                updateJson();
            });
        }

        // Handle click on box2 to hide child items only
        const box2 = txtWrapper.querySelector('.box2');
        if (box2) {
            box2.addEventListener('click', (event) => {
                event.stopPropagation(); // Prevent triggering other click events
                const parentLi = txtWrapper.closest('.tree-list');
                const childUl = parentLi.querySelector('ul');

                // Toggle visibility of child elements
                if (childUl) {
                    const isHidden = childUl.style.display === 'none';
                    childUl.style.display = isHidden ? 'block' : 'none'; // Toggle display of children
                    // Rotate box2
                    box2.classList.toggle('rotated', !isHidden); // Rotate based on visibility
                    box2.classList.toggle('visible', !isHidden);
                }

                // Update box2 display based on child items
                checkChildItems();
            });
        }
    };

    function buildJsonFromTree(container) {
        const result = [];

        // Get all direct child <li> elements
        const children = container.querySelectorAll(':scope > li.tree-list');
        children.forEach(child => {
            const label = child.querySelector('.txt-wrapper textarea').value || 'Untitled';
            const childJson = {
                label: label,
                children: []
            };

            // Check for nested <ul> and build children recursively
            const nestedUl = child.querySelector('ul');
            if (nestedUl) {
                childJson.children = buildJsonFromTree(nestedUl);
            }

            result.push(childJson);
        });

        return result;
    }

    function updateJson() {
        const treeContainer = document.querySelector('.tree-children > ul');
        const label = document.querySelector('.txt-wrapper.root textarea').value || 'Untitled';

        const finalJson = {
            label: label,
            children: []
        };

        // Check if treeContainer exists and has child <li> elements
        if (treeContainer && treeContainer.querySelector('li.tree-list')) {
            const jsonStructure = buildJsonFromTree(treeContainer);
            finalJson.children = jsonStructure;
        }

        console.log(JSON.stringify(finalJson, null, 2));

        // Store the JSON in local storage
        localStorage.setItem('treeData', JSON.stringify(finalJson));

    }

    const addParentSubLevelClickHandler = (target) => {
        const html = `
            <li class="tree-list">
                <div class="txt-wrapper"> 
                    <textarea class="dis" maxlength="250">New Label</textarea>
                    <div class="box box1" style="display: none;"><i class="fal fa-minus"></i></div>
                    <div class="box box2" style="display: none;"><i class="fas fa-sort-up"></i></div>
                </div>
            </li>`;

        const treeChildren = document.querySelector('.tree-children');
        treeChildren.style.display = 'block';

        // Create a new <ul> inside the .tree-children if it doesn't exist
        let newUl = treeChildren.querySelector('ul'); // Look for an existing <ul> inside .tree-children
        if (!newUl) {
            newUl = document.createElement('ul'); // Create a new <ul>
            treeChildren.appendChild(newUl); // Append the <ul> to the .tree-children
        }
        // Insert the new list item into the existing or new <ul>
        newUl.insertAdjacentHTML('beforeend', html);

        const newTxtWrapper = newUl.lastElementChild.querySelector('.txt-wrapper');
        attachTxtWrapperEvents(newTxtWrapper);

        updateBox2Visibility(target);

        // After adding a child, update the JSON
        updateJson();

    };


    const addSubLevelClickHandler = (currentWrapper) => {
        let existingUl = currentWrapper.parentNode.querySelector('ul');

        if (!existingUl) {
            const html = `
            <li class="tree-list">
                <div class="txt-wrapper"> 
                    <textarea class="dis" maxlength="250">New Label</textarea>
                    <div class="box box1" style="display: none;"><i class="fal fa-minus"></i></div>
                    <div class="box box2" style="display: none;"><i class="fas fa-sort-up"></i></div>
                </div>
            </li>`;

            const newUl = document.createElement('ul');
            newUl.innerHTML = html;
            currentWrapper.parentNode.insertBefore(newUl, currentWrapper.nextSibling);

            const newTxtWrapper = newUl.querySelector('.txt-wrapper');
            attachTxtWrapperEvents(newTxtWrapper);
        } else {
            const html = `
            <li class="tree-list">
                <div class="txt-wrapper"> 
                    <textarea class="dis" maxlength="250">New Label</textarea>
                    <div class="box box1" style="display: none;"><i class="fal fa-minus"></i></div>
                    <div class="box box2" style="display: none;"><i class="fas fa-sort-up"></i></div>
                </div>
            </li>`;

            existingUl.insertAdjacentHTML('beforeend', html);
            const newTxtWrapper = existingUl.lastElementChild.querySelector('.txt-wrapper');
            attachTxtWrapperEvents(newTxtWrapper);
        }

        updateBox2Visibility(currentWrapper);

        // After adding a child, update the JSON
        updateJson();
    };

    const addRightLevelClickHandler = (currentWrapper) => {
        const html = `
            <li class="tree-list">
                <div class="txt-wrapper">
                    <textarea class="dis" maxlength="250">New Label</textarea>
                    <div class="box box1" style="display: none;"><i class="fal fa-minus"></i></div>
                    <div class="box box2" style="display: none;"><i class="fas fa-sort-up"></i></div>
                </div>
            </li>`;

        const parentLi = currentWrapper.closest('.tree-list');
        parentLi.insertAdjacentHTML('afterend', html);

        const newRightLevelTextWrapper = parentLi.nextElementSibling.querySelector('.txt-wrapper');
        attachTxtWrapperEvents(newRightLevelTextWrapper);

        // updateBox2Visibility(parentLi.closest('.txt-wrapper'));

        // After adding a child, update the JSON
        updateJson();
    };

    const addLeftLevelClickHandler = (currentWrapper) => {
        const html = `
            <li class="tree-list">
                <div class="txt-wrapper">
                    <textarea class="dis" maxlength="250">New Label</textarea>
                    <div class="box box1" style="display: none;"><i class="fal fa-minus"></i></div>
                    <div class="box box2" style="display: none;"><i class="fas fa-sort-up"></i></div>
                </div>
            </li>`;

        const parentLi = currentWrapper.closest('.tree-list');
        parentLi.insertAdjacentHTML('beforebegin', html);

        const newLeftLevelTextWrapper = parentLi.previousElementSibling.querySelector('.txt-wrapper');
        attachTxtWrapperEvents(newLeftLevelTextWrapper);

        // updateBox2Visibility(parentLi.closest('.txt-wrapper'));

        // After adding a child, update the JSON
        updateJson();
    };

    // Add event listeners for mouse enter/leave
    wrapper.addEventListener('mouseenter', () => createAddBottomLevelButton(wrapper));
    wrapper.addEventListener('mouseleave', () => removeAddBottomLevelButton(wrapper));

    // Update box2 visibility when children are modified
    const checkChildItems = () => {
        updateBox2Visibility(wrapper);
    };

    // Add click event listener to wrapper
    wrapper.addEventListener('click', function (event) {
        const addSubLevelButton = event.target.closest('.add-bottom-level');
        if (addSubLevelButton) {
            addParentSubLevelClickHandler(wrapper);
            return;
        }

        const activeWrapper = document.querySelector('.txt-wrapper.active');
        if (activeWrapper && activeWrapper !== wrapper) {
            activeWrapper.classList.remove('active');
            const textarea = activeWrapper.querySelector('textarea');
            if (textarea) {
                textarea.classList.add('dis');
            }

            const activeBox2 = activeWrapper.querySelector('.box2');
            if (activeBox2) activeBox2.style.display = 'none';
        }

        const box2 = wrapper.querySelector('.box2');
        const childUl = wrapper.closest('.tree-list').querySelector('ul');
        const hasChildren = childUl && childUl.children.length > 0; // Check for child elements

        const isActive = wrapper.classList.toggle('active');
        if (isActive) {
            if (hasChildren) {
                if (box2) box2.style.display = 'block';
                // Add click event listener to box2 only when it's shown
                if (box2) {
                    box2.addEventListener('click', handleBox2Click);
                }
            } else {
                if (box2) box2.style.display = 'none'; // Hide box2 if no children
            }
        } else {
            if (box2) box2.style.display = 'none';
            // Optionally, remove the event listener when box2 is hidden
            if (box2) {
                box2.removeEventListener('click', handleBox2Click);
            }
        }
    });

    // Function to handle click on box2
    function handleBox2Click(event) {
        event.stopPropagation(); // Prevent triggering other click events
        const parentLi = wrapper.closest('.tree-list');
        const childUl = parentLi.querySelector('ul');
        const box2 = wrapper.querySelector('.box2');

        // alert('ok'); // Alert

        // Toggle visibility of child elements
        if (childUl) {
            const isHidden = childUl.style.display === 'none';
            childUl.style.display = isHidden ? 'block' : 'none'; // Toggle display of children
            // Rotate box2
            box2.classList.toggle('rotated', !isHidden); // Rotate based on visibility
            box2.classList.toggle('visible', !isHidden);
        }

        // Update box2 display based on child items
        checkChildItems();
    }

    // Handle double-click to edit the textarea
    wrapper.addEventListener('dblclick', function () {
        const textarea = wrapper.querySelector('textarea');
        if (textarea) {
            textarea.classList.remove('dis'); // Remove 'dis' class to enable editing
            textarea.focus(); // Focus on the textarea
        }
    });

    // Handle input to capture value in the textarea
    wrapper.addEventListener('input', function (event) {
        const textarea = event.target.closest('textarea');
        if (textarea) {
            textarea.innerHTML = textarea.value;
            textarea.style.height = '20px'; // Reset height
            textarea.style.height = `${textarea.scrollHeight}px`; // Set new height    
            updateJson();
        }
    });

    document.addEventListener('click', function (event) {

        if (!event.target.closest('.txt-wrapper')) {

            const textareas = document.querySelectorAll('textarea');

            textareas.forEach(textarea => {
                // Check if the textarea does not have the 'dis' class
                if (!textarea.classList.contains('dis')) {
                    textarea.classList.add('dis');
                    textarea.blur();
                };
            });

            const activeWrapper = document.querySelector('.txt-wrapper.active');

            if (activeWrapper) {
                activeWrapper.classList.remove('active');


                const activeBox1 = activeWrapper.querySelector('.box1');
                const activeBox2 = activeWrapper.querySelector('.box2');
                if (activeBox1) activeBox1.style.display = 'none';
                if (activeBox2) activeBox2.style.display = 'none';
            } else {
                // Check for all .txt-wrapper elements
                const allWrappers = document.querySelectorAll('.txt-wrapper');
                allWrappers.forEach(wrapper => {
                    const box1 = wrapper.querySelector('.box1');
                    const box2 = wrapper.querySelector('.box2');
                    if (box1) box1.style.display = 'none';
                    if (box2) box2.style.display = 'none';
                });
            }
        }
    });
}

document.addEventListener("DOMContentLoaded", function () {
    const canvasContainer = document.getElementById('canvas_container');
    const svgTarget = document.getElementById('target');

    // Function to get and log the screen dimensions
    function checkScreenDimensions() {
        var screenWidth = window.innerWidth;
        var screenHeight = window.innerHeight;

        canvasContainer.style.height = screenHeight + 'px';
        canvasContainer.style.width = screenWidth + 'px';

        canvasWrapper();
    }

    // Center the canvas horizontally in the viewport
    function centerCanvas() {
        const canvas = document.getElementById('canvas');

        const centerX = (canvas.offsetWidth - canvasContainer.clientWidth) / 2;

        // Scroll to center the canvas
        canvasContainer.scrollTo(centerX, 0);
    }

    // Check initial screen dimensions and center canvas
    checkScreenDimensions();
    centerCanvas();

    // Add event listener for window resize
    window.addEventListener("resize", function () {
        checkScreenDimensions();
        centerCanvas();
    });


    svgTarget.addEventListener('click', function () {
        centerCanvas();
    });

    // Click-and-hold dragging functionality
    let isDragging = false;
    let lastMouseX, lastMouseY;

    const handleMouseDown = (e) => {
        isDragging = true;
        lastMouseX = e.clientX;
        lastMouseY = e.clientY;

        // Prevent text selection
        e.preventDefault();
    };

    const handleMouseMove = (e) => {
        if (!isDragging) return;

        const deltaX = lastMouseX - e.clientX;
        const deltaY = lastMouseY - e.clientY;

        canvasContainer.scrollBy(deltaX, deltaY);

        lastMouseX = e.clientX;
        lastMouseY = e.clientY;
    };

    const handleMouseUp = () => {
        isDragging = false;
    };

    // Event listeners for dragging
    canvasContainer.addEventListener('mousedown', handleMouseDown);
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
});

document.addEventListener("DOMContentLoaded", function () {
    const download = document.getElementById('download'); // Corrected ID

    function buildJsonFromTree(container) {
        const result = [];

        // Get all direct child <li> elements
        const children = container.querySelectorAll(':scope > li.tree-list');
        children.forEach(child => {
            const label = child.querySelector('.txt-wrapper textarea').value || 'Untitled';
            const childJson = {
                label: label,
                children: []
            };

            // Check for nested <ul> and build children recursively
            const nestedUl = child.querySelector('ul');
            if (nestedUl) {
                childJson.children = buildJsonFromTree(nestedUl);
            }

            result.push(childJson);
        });

        return result;
    }

    function downloadJson(jsonData, filename) {
        // Convert the JSON object to a string
        const jsonString = JSON.stringify(jsonData, null, 2);

        // Create a blob from the JSON string
        const blob = new Blob([jsonString], { type: 'application/json' });

        // Create a link element
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = filename;

        // Programmatically click the link to trigger the download
        document.body.appendChild(link);
        link.click();

        // Clean up and remove the link
        document.body.removeChild(link);
    }

    download.addEventListener('click', function () {
        const treeContainer = document.querySelector('.tree-children > ul');
        const label = document.querySelector('.txt-wrapper.root textarea').value || 'Untitled';

        const finalJson = {
            label: label,
            children: []
        };

        // Check if treeContainer exists and has child <li> elements
        if (treeContainer && treeContainer.querySelector('li.tree-list')) {
            const jsonStructure = buildJsonFromTree(treeContainer);
            finalJson.children = jsonStructure;
        }

        downloadJson(finalJson, 'treeData.json');
    });
});

